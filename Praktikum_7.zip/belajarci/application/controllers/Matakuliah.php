<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Matakuliah extends CI_Controller {

    public function index() {
        $this->load->model('matakuliah_model','matkul1');
        $this->matkul1->id=1;
        $this->matkul1->kode='010001';
        $this->matkul1->nama='Kamanan Sistem Dan Jaringan Komputer';
        $this->matkul1->jumlah_sks=3;

        $this->load->model('matakuliah_model','matkul2');
        $this->matkul2->id=2;
        $this->matkul2->kode='020001';
        $this->matkul2->nama='UI UX';
        $this->matkul2->jumlah_sks=2;

        $list_matkul = [$this->matkul1, $this->matkul2];
        $data['list_matkul']=$list_matkul;

        $this->load->view('header');
        $this->load->view('matakuliah/index',$data);
        $this->load->view('footer');
    }

}