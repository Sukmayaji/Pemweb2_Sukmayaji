<?php

class Matakuliah_model extends CI_Model {

    public $id;
    public $nama_matkul;
    public $kode_matkul;
    public $jumlah_sks;

}