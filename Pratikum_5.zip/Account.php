<?php 

class Account {
    public $no;
    public $saldo;

    public function __construct($no, $saldo) {
        $this->no = $no;
        $this->saldo = $saldo;
    }

    public function deposit($value) {
        $this->saldo = $this->saldo - $value;
    }

    public function withdraw($value) {
        $this->saldo = $this->saldo + $value;
    }

    public function cetak() {
        echo "Resi " . $no . "<br/>";
        echo "Saldo " . $saldo . "<br/>";
    }
}



?>