<?php

require("Account.php");


class Account_Bank extends Account {
    public $nama;
}


$account1 = new Account_Bank("C001", 600000);
$account1->nama = "Ahmad";

$account2 = new Account_Bank("C002", 535000);
$account2->nama = "Budi";

$account3 = new Account_Bank("C003", 250000);
$account3->nama = "Kurniawan";

$account1->withdraw(100000);

$account1->deposit(1500000);
$account3->withdraw(1500000);

$account1->deposit(500000);
$account2->withdraw(500000);

$account2->deposit(2500000);

?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Praktikum 5</title>
</head>
<body>
    <table>
        <tr>
            <td>
                No Account
            </td>
            <td>
                Nama
            </td>
            <td>
                Saldo
            </td>
        </tr>
        <tr>
            <td><?php echo $account1->no?></td>
            <td><?php echo $account1->nama?></td>
            <td><?php echo $account1->saldo?></td>
        </tr>   
        <tr>
            <td><?php echo $account2->no?></td>
            <td><?php echo $account2->nama?></td>
            <td><?php echo $account2->saldo?></td>
        </tr>   
        <tr>
            <td><?php echo $account3->no?></td>
            <td><?php echo $account3->nama?></td>
            <td><?php echo $account3->saldo?></td>
        </tr>   
    </table>
</body>
</html>
