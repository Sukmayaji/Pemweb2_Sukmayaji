# praktikum3_BMI
 Praktikum 03 by Ahmad Fauzan
