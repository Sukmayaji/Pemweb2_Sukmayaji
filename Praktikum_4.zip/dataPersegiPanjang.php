<?php

require_once "classPersegiPanjang.php";
echo "Nilai Persegi Panjang";

$p1 = new PersegiPanjang (10, 3);
$p2 = new PersegiPanjang (4, 7);

echo "<br/>Luas PersegiPanjang 1 " . $p1->getLuas();
echo "<br/>Luas PersegiPanjang 2 " . $p2->getLuas();


echo "<br/>Keliling PersegiPanjang 1 " . $p1->getKeliling();
echo "<br/>Keliling PersegiPanjang 2 " . $p2->getKeliling();
