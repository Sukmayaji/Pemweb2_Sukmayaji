<?php

require_once "classLingkaran.php";
echo "Nilai PHI " . Lingkaran::PHI;

$l1 = new Lingkaran (10);
$l2 = new Lingkaran (4);

echo "<br/>Luas Lingkaran 1 " . $l1->getLuas();
echo "<br/>Luas Lingkaran 2 " . $l2->getLuas();


echo "<br/>Keliling Lingkaran 1 " . $l1->getKeliling();
echo "<br/>Keliling Lingkaran 2 " . $l2->getKeliling();
